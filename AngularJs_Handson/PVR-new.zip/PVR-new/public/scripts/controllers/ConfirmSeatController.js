(function () {

'use strict';
angular.module('PVRCinemas').controller("ConfirmTicketCtrl", ConfirmTicketCtrl);

ConfirmTicketCtrl.$inject = ['$scope','$rootScope','$http'];
function ConfirmTicketCtrl($scope,$rootScope,$http) {
	
	$scope.bookTicket = bookTicketFn;
	$scope.getTicketDetails = getTicketDetailsFn;
	if(
	   (!$rootScope.movie) || 
	   (!$rootScope.theatre) || 
	   (!$rootScope.date) || 
	   (!$rootScope.show) || 
	   (!$rootScope.selectedSeatsList) || 
	   ($rootScope.selectedSeatsList.length == 0)
	  )
		window.location = "#/";
	else {
		$scope.getTicketDetails();
		$scope.bookTicket($rootScope.movie, $rootScope.theatre, $rootScope.date, $rootScope.show, $rootScope.selectedSeatsList);
	}
	
	function getTicketDetailsFn() {
		var req = {
			method: 'GET',
			url: '/getTicketDetails',
			params: {
				movie: $rootScope.movie, 
				date: $rootScope.date,
				theatre: $rootScope.theatre,
				show: $rootScope.show,
				seats: $rootScope.selectedSeatsList
			}
		}
		
		$http(req).then(successGetTicketDetailsFn, function(){});
	}
	function successGetTicketDetailsFn(res) {
		$scope.movie = res.data.movie;
		$scope.date = res.data.date;
		$scope.theatre = res.data.theatre;
		$scope.show = res.data.show;
		$scope.seats = $rootScope.selectedSeatsList.toString();
	}
	
	function bookTicketFn(_movie, _theatre, _date, _show, _selectedSeatsList) {
		var req = {
			method: 'POST',
			url: '/bookTicket',
			data: {
				movie: _movie,
				theatre: _theatre,
				date: _date,
				show: _show,
				selectedSeatsList: _selectedSeatsList.toString() 
			}
		}
		$http(req).then(function(){}, function(){});
	}
	
}
})();