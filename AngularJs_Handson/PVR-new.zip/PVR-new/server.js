(function () {

var fs = require('fs');
var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');
var Datastore = require('nedb'), seatBooking = new Datastore({ filename: 'pvr.db', autoload: true });
var loginAdminDb = new Datastore({ filename: 'login'});
loginAdminDb.loadDatabase();

var app = express();
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

var loginDetails = [{'name':'Ranjitha', 'email':'ranjitha.sn4@tcs.com' , 'password':'ranju'}];

//var getIP = require('ipware')().get_ip;
loginAdminDb.insert(loginDetails);

app.get('/getLoginDetails',function(req,res){
	console.log(req.query);
	var email = req.query.email;
	var password = req.query.password;
	console.log(email);
	loginAdminDb.find({email:email , password:password}).exec(function(err,docs){
		console.log(docs);
		res.send(docs);
	});
	
});



function getDatesFn(dayNum) {
	var keyMul = (24 * 60 * 60 * 1000) * dayNum;
	
	var nextDate = new Date(new Date().getTime() + keyMul);
	var day = nextDate.getDate();
	day = ("0" + day).slice(-2);
	var month = nextDate.getMonth() + 1;
	month = ("0" + month).slice(-2);
	var year = nextDate.getFullYear();
	
	var _date = {"id" : dayNum,"name" : day + "-" + month + "-" + year};
	return _date;
}
app.get('/getLanguages', function(req, res) {

	fs.readFile('./pvr.json', 'utf8', function (err, data) {
	  if (err) throw err;
	  res.send(data);
	});	
});
app.get('/getMovies', function(req, res) {
	var obj;
	fs.readFile('./pvr.json', 'utf8', function (err, data) {
	  if (err) throw err;
	  res.send(data);
	});	
});

app.get('/getDetails', function(req, res) {
	var obj;
	var movies=[];
	fs.readFile('./pvr_lang.json', 'utf8', function (err, data) {
	  if (err) throw err;
	  obj = JSON.parse(data);
	  
	  for(var ictr = 0; ictr < obj[req.query.language].length; ictr++) {
		  movies.push(obj[req.query.language][ictr].movie);
	  }
	
	fs.readFile('./pvr.json', 'utf8', function (err, data) {
		  if (err) throw err;
		  var movieDetails = {};
		  movieDetails['movies'] = [];
	      obj = JSON.parse(data);
	      for(var ictr = 0; ictr < obj.movies.length; ictr++) {
			  if(movies.indexOf(obj.movies[ictr].id) != -1)
				  movieDetails['movies'].push(obj.movies[ictr])
		  }
		  res.send(JSON.stringify(movieDetails));
	  });
	});
});
	
	
	
	
app.get('/getOthers', function(req, res) {
	var obj;
	var theatres = [];
	var shows = [];

	fs.readFile('./pvr_movies.json', 'utf8', function (err, data) {
	  if (err) throw err;
	  obj = JSON.parse(data);
	  
	  for(var ictr = 0; ictr < obj[req.query.movie].length; ictr++) {
		  theatres.push(obj[req.query.movie][ictr].theatre);
		  shows.push(obj[req.query.movie][ictr].show);
	  }
	  
	  
	  
	 fs.readFile('./pvr.json', 'utf8', function (err, data) {
		  if (err) throw err;
		  var theatreDetails = {};
		  theatreDetails['shows'] = [];
		  theatreDetails['theatres'] = [];
		  theatreDetails['dates'] = [];
		  
		  obj = JSON.parse(data);
		  for(var ictr = 0; ictr < obj.shows.length; ictr++) {
			  if(shows.indexOf(obj.shows[ictr].id) != -1)
				  theatreDetails['shows'].push(obj.shows[ictr])
		  }
		  
		  for(var ictr = 0; ictr < obj.theatres.length; ictr++) {
			  if(theatres.indexOf(obj.theatres[ictr].id) != -1)
				  theatreDetails['theatres'].push(obj.theatres[ictr])
		  }
		  
		  theatreDetails['dates'].push(getDatesFn(1));
		  theatreDetails['dates'].push(getDatesFn(2));
		  
		  res.send(JSON.stringify(theatreDetails));
		});  
	});
});

app.get('/getTicketDetails', function(req, res) {
	var obj;
	var ticketDetails = {};
	ticketDetails['movie'] = "";
	ticketDetails['theatre'] = "";
	ticketDetails['show'] = "";
	ticketDetails['date'] = "";
	
	fs.readFile('./pvr.json', 'utf8', function (err, data) {
	  if (err) throw err;
	  obj = JSON.parse(data);
	  
	  for(var ictr = 0; ictr < obj.movies.length; ictr++) {
		  if(obj.movies[ictr].id == req.query.movie)
			  ticketDetails['movie'] = obj.movies[ictr].name;
	  }
	  
	  for(var ictr = 0; ictr < obj.theatres.length; ictr++) {
		  if(obj.theatres[ictr].id == req.query.theatre)
			  ticketDetails['theatre'] = obj.theatres[ictr].name;
	  }
	  
	  for(var ictr = 0; ictr < obj.shows.length; ictr++) {
		  if(obj.shows[ictr].id == req.query.show)
			  ticketDetails['show'] = obj.shows[ictr].name;
	  }

	  ticketDetails['date'] = getDatesFn(req.query.date).name;
	  
	  res.send(JSON.stringify(ticketDetails));
	});	
});

app.post('/bookTicket', function(req, res) {
	seatBooking.insert({
						movie: req.body.movie,
						theatre: req.body.theatre,
						date: req.body.date,
						show: req.body.show,
						selectedSeatsList: req.body.selectedSeatsList
					   },
					   function (err) {
		
	});
	
    res.send("");
});


app.get('/checkSeats', function(req, res) {
	var selectedSeats = "";
	var selectedSeatsCount = 0;
	seatBooking.find({ show: req.query.show }, function (err, docs) {
		for(var ictr = 0; ictr < docs.length; ictr++) {
			selectedSeats += docs[ictr].selectedSeatsList + ",";
		}
		selectedSeatsCount = selectedSeats.split(",").length-1;
		console.log(selectedSeatsCount);
		res.send({seats:selectedSeats,count:selectedSeatsCount});
	});
});

app.listen(process.env.PORT || 8081);
console.log("Server is listening");

})();