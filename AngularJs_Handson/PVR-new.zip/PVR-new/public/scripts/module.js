(function () {
		 
	'use strict';
	var PVRCinemas = angular.module('PVRCinemas', ['ngRoute', 'ui.bootstrap']);
	
	PVRCinemas.config(function($routeProvider) {
        $routeProvider

			.when('/', {
                templateUrl : './views/home.html'
            })
			
            .when('/bookTicket', {
                templateUrl : './views/bookTicket.html'
            })
			
			.when('/confirmTicket', {
                templateUrl : './views/confirmTicket.html',
            })
			.when('/login',{
				templateUrl : './views/login.html',
			});
    });
	
})();