(function() {
	'use strict';
	angular
		.module('myPVR')
		.controller('MovieList',MovieList);
		
	MovieList.$inject = ['$scope','$http'];
	
	function MovieList($scope,$http) {
		$http
			.get('./pvr.json')
			.success(function(data){
					$scope.movies = data;
					console.log("data.movies");
				})
			.error(function(err){
					console.log(err);
				}
				);
	};
	

})();
