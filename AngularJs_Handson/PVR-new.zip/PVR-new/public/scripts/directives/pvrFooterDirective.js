(function () {

'use strict';
angular.module('PVRCinemas').directive("pvrFooter", pvrFooter);

function pvrFooter() {
	return {
		restrict: 'E',
		templateUrl: './views/pvr-footer.html'
	  };
}
})();