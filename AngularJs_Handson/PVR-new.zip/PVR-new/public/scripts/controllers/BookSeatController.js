(function () {

'use strict';
angular.module('PVRCinemas').controller("BookSeatCtrl", BookSeatCtrl);

BookSeatCtrl.$inject = ['$scope','$rootScope','$http'];
function BookSeatCtrl($scope,$rootScope,$http) {

	if(
		(!$rootScope.movie) || 
		(!$rootScope.date) || 
		(!$rootScope.theatre) || 
		(!$rootScope.show)
	) {
		window.location = "#/";
	}
	
	$rootScope.selectedSeatsList = [];
	
	$scope.rows = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
	$scope.cols = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
	$scope.count = 0;
	
	$scope.checkSeats = checkSeatsFn;
	$scope.confirmSeats = confirmSeatsFn;
	$scope.selectedSeats = selectedSeatsFn;
	$scope.getTicketDetails = getTicketDetailsFn;
	
	$scope.getTicketDetails();
	$scope.checkSeats($rootScope.show);
	
	function getTicketDetailsFn() {
		var req = {
			method: 'GET',
			url: '/getTicketDetails',
			params: {
				movie: $rootScope.movie,
				date: $rootScope.date,
				theatre: $rootScope.theatre,
				show: $rootScope.show
			}
		}
		$http(req).then(successGetTicketDetailsFn, function(){});
	}
	
	function successGetTicketDetailsFn(res) {
		$scope.movie = res.data.movie;
		$scope.date = res.data.date;
		$scope.theatre = res.data.theatre;
		$scope.show = res.data.show;
	}
	
	function checkSeatsFn(_show) {
		var req = {
			method: 'GET',
			url: '/checkSeats',
			params: {
				show: _show
			}
		}
		$http(req).then(successCallbackSeats, function(){});
	}
	
	function successCallbackSeats(res) {
		var seatsList = res.data.seats.split(",");
		console.log(res.data.count);
		for(var ictr = 0; ictr < (seatsList.length - 1); ictr++) {
			$("#seatTd" + seatsList[ictr]).removeClass();
			$("#seatTd" + seatsList[ictr]).addClass("color-10");
		}
	}
	
	function confirmSeatsFn() {
		window.location = "#/confirmTicket";
	}
	
	function selectedSeatsFn(_id) {
		if(!$("#seatTd" + _id).hasClass("color-10")) {
			if($rootScope.selectedSeatsList.indexOf(_id) == -1) {
				if($scope.count < 10) {
					$rootScope.selectedSeatsList.push(_id);
					$("#seatTd" + _id).removeClass();
					$("#seatTd" + _id).addClass("color-9");
					$scope.count++;
				}
			}
			else {
				$rootScope.selectedSeatsList.splice( $.inArray(_id, $rootScope.selectedSeatsList), 1 );
				$("#seatTd" + _id).removeClass();
				$("#seatTd" + _id).addClass("color-0");
				$scope.count--;
			}
			
			$scope.seats = $rootScope.selectedSeatsList.toString();
			
		}
		else {
			return false;
		}
	}
}
})();