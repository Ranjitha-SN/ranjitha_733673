(function () {

'use strict';
angular.module('PVRCinemas').controller('HomeCtrl', HomeCtrl);

HomeCtrl.$inject = ['$scope','$rootScope','$http'];
function HomeCtrl($scope,$rootScope,$http) {

	$scope.myInterval = 2000;
	$scope.noWrapSlides = false;
	$scope.active = 0;
	var slides = $scope.slides = [];
	var pics = $scope.pics = [];
	var photos = $scope.photos = [];
	
	var currIndex = 0;
	$scope.movie = "0";
	$scope.date = "0";
	$scope.theatre = "0";
	$scope.show = "0";
	$scope.language = "0";
	$scope.city = "0";
	$scope.seatCount = 0;
	
	$scope.addSlide = addSlideFn;
	$scope.getMovies = getMoviesFn;
	$scope.getDetails= getDetailsFn;
	$scope.getOthers = getOthersFn;
	$scope.getLanguages = getLanguagesFn;
	$scope.chooseSeats = chooseSeatsFn;
	$scope.trending = trendingFn;
	$scope.upcoming = upcomingFn;
	$scope.checkSeats = checkSeatsFn;
	
	function addSlideFn(j) {
		slides.push({
		  image: './assets/images/slides/' + j + '.jpg',
		  id: currIndex++
		});
	}
	
	function trendingFn(j){
		pics.push({
		image: './assets/images/trending/' + j + '.jpg'
		
	});
	}
	function upcomingFn(j){
		photos.push({
		image: './assets/images/upcoming/' + j + '.jpg'
		
	});console.log(photos);
	}
		
	
	function successGetLanguages(res){
		$scope.languageList=res.data.languages;
		$scope.cityList=res.data.cities;
	}
	function successGetPVRMovies(res) {
		$scope.moviesList = res.data.movies;
		$scope.datesList = res.data.dates;
	}
	function getLanguagesFn() {
		var req = {
			method: 'GET',
			url: '/getLanguages'
		}
		$http(req).then(successGetLanguages, function(){});
	}
	function getMoviesFn() {
		var req = {
			method: 'GET',
			url: '/getMovies'
		}
		$http(req).then(successGetPVRMovies, function(){});
	}
	
	function getDetailsFn() {
		var req = {
			method: 'GET',
			url: '/getDetails',
			params: {
				language : $scope.language
				}
		}
		$http(req).then(successDetailsFn, function(){});
	}
	
	
	
	function getOthersFn() {
		var req = {
			method: 'GET',
			url: '/getOthers',
			params: {
				movie : $scope.movie
				}
		}
		$http(req).then(successOthersFn, function(){});
	}
	
	function successDetailsFn(res) {
		$scope.moviesList = res.data.movies;
	}
	
	function successOthersFn(res) {
		$scope.theatresList = res.data.theatres;
		$scope.showsList = res.data.shows;
		$scope.datesList = res.data.dates;
	}
		function checkSeatsFn(_show) {
		var req = {
			method: 'GET',
			url: '/checkSeats',
			params: {
				show: _show
			}
		}
		$http(req).then(successCallbackSeats, function(){});
	}
	
	function successCallbackSeats(res) {
		var seatsList = res.data.seats.split(",");
		$scope.seatCount = res.data.count;
		console.log(res.data.count);
		for(var ictr = 0; ictr < (seatsList.length - 1); ictr++) {
			$("#seatTd" + seatsList[ictr]).removeClass();
			$("#seatTd" + seatsList[ictr]).addClass("color-10");
		}
	}
	function chooseSeatsFn() {
		
		if ($scope.city=="0")
		{
			
			document.getElementById('city').focus();
			return false;
		}
		if ($scope.language=="0")
		{
			
			document.getElementById('language').focus();
			return false;
		}
		if ($scope.movie=="0")
		{
			
			document.getElementById('movie').focus();
			return false;
		}
		if ($scope.date=="0")
		{
			
			document.getElementById('date').focus();
			return false;
		}
		if ($scope.theatre=="0")
		{
			
			document.getElementById('theatre').focus();
			return false;
		}
		if ($scope.show=="0")
		{
			
			document.getElementById('show').focus();
			return false;
		}

		$rootScope.movie = $scope.movie;
		$rootScope.date = $scope.date;
		$rootScope.theatre = $scope.theatre;
		$rootScope.show = $scope.show;
		
		window.location = "#/bookTicket";
	}
	
	for (var i = 1; i <= 6; i++) {
		$scope.addSlide(i);
	}
	
	for (var i = 1; i <= 6; i++) {
		$scope.trending(i);
	}
	
	for (var i = 1; i <= 6; i++) {
		$scope.upcoming(i);
	}
	$scope.getLanguages();
		$scope.checkSeats($rootScope.show);
	
}
})();