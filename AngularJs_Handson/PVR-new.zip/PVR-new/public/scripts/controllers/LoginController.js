(function(){
	'use strict';
	angular
		.module('PVRCinemas')
		.controller('loginCtrl',loginCtrl);
	
	loginCtrl.$inject = ['$scope','$http','$location'];
	
	function loginCtrl($scope,$http,$location) {
		$scope.loginSubmit = function() {
			//var emailLowerCase= $filter('lowercase')($scope.emailId);
			console.log($scope.emailId);
			console.log($scope.pass);
			//console.log(emailLowerCase);
			$http({
				method: "GET",
				url: '/getLoginDetails', 			 
				params: { email: $scope.emailId, password:$scope.pass }
			})
			.success(function(data){
				console.log(data.length);
				if(data.length > 0) {
					console.log("Successfully Logged In");
					$scope.notAdmin = false;
					$location.path('/home')
				}
				else {
					$scope.notAdmin = true;
				}
			})
			.error(function(err){
				$location.path('/login')
				console.log(err);
			});
		}
		
	}
})();