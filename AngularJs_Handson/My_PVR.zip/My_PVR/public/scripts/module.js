(function() {
	angular
		.module('myPVR',[]);


})();